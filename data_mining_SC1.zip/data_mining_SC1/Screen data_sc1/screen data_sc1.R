install.packages("zCompositions")
install.packages("robCompositions")
install.packages("tidyverse")
install.packages("ggplot2")

library(zCompositions)
library(robCompositions)
library(tidyverse)
library(ggplot2)

start.time<-Sys.time()
setwd("/Users/haimingliu/Documents/Post doc research/Screen data/")
file.name.compo.sum.03<-"03.data.sum.csv"

#composition-------------
compo<-read.csv("02.data_sc1.csv",header = TRUE, 
                sep = ",", stringsAsFactors = FALSE)
compo.active<- compo[ ,2:48]
compo.active[compo.active == 0] <- NA
summary (compo.active)
setwd("/Users/haimingliu/Documents/Post doc research/Screen data/")
sumdata <-summary(compo.active)
write.table(sumdata,file.name.compo.sum.03,sep = ",",row.names = FALSE)

#screen data-----------
pattern.id<-
  zPatterns(compo.active[,1:47],label = NA, bar.colors = c("#caff70","#a2cd5a"),
            bar.labels = TRUE,cell.colors = c("green4","white"),
            cell.labels =c("Nondetected","Observed"),
            cex.axis = 0.8)
ggsave("screen scheelite data.png")
