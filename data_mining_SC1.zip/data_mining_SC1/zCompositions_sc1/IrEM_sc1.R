install.packages("zCompositions")
install.packages("robCompositions")
install.packages("tidyverse")

library(zCompositions)
library(robCompositions)
library(tidyverse)

start.time<-Sys.time()
setwd("/Users/haimingliu/Documents/Post doc research/zCompositions/")
file.name.compo.imp.03<-"03.data.lrem.csv"

#composition-------------
compo<-read.csv("02.data_sc1.csv",header = TRUE, 
                sep = ",", stringsAsFactors = FALSE)
compo.<-compo[2:ncol(compo)]#change the starting number according to your dataset

compo. [compo. < 0] <- 0
compo. [is.na(compo.)] <- 0
summary(compo.)
#detection limits-----------
LOD<-read.csv("02.data_dl_sc1.csv",header = TRUE, sep = ",", stringsAsFactors = FALSE,
              row.names = 1)
LOD<-as.matrix(LOD)
summary(LOD)
#check negative values in both datasets
negative_values <- LOD[LOD < 0]
if (length(negative_values) > 0) {
  cat("Negative values found in LOD.\n")
  cat("Number of negative values:", length(negative_values), "\n")
  cat("Indices of negative values:", which(LOD < 0), "\n")
} else {
  cat("No negative values found in LOD.\n")
}

pattern.id<-
  zPatterns(compo.,label = 0, bar.colors = c("#caff70","#a2cd5a"),
            bar.labels = TRUE,cell.colors = c("green4","white"),
            cell.labels =c("Nondetected","Observed"),
            cex.axis = 0.8)

#=======IMPUTATION=================================
compo.imp<-lrEM(compo.,
                label = 0,
                dl=LOD,
                rob=FALSE,
                tolerance=0.0001,
                ini.cov="multRepl",
                max.iter = 50,
                z.warning=0.95,
                closure= 10^6)
compo.imp["Line"]<-compo[,1]
compo.imp <- compo.imp %>%
  dplyr::select("Line", everything())
format(compo.imp,scientific=FALSE)
#output the imputation results
setwd("/Users/haimingliu/Documents/Post doc research/zCompositions/")
write.table(compo.imp,file.name.compo.imp.03,sep = ",",row.names = FALSE)
