library(zCompositions)
library(robCompositions)
library(tidyverse)

start.time<-Sys.time()
setwd("/Users/haimingliu/Documents/Post doc research/clr transformation/")
file.name.compo.imp.clr.03<-"03.data.lrem.clr.csv"

compo.imp<-read.csv("02.data_imp_sc1.csv",header = TRUE,
                    sep = ",", stringsAsFactors = FALSE)
#CLR transformation-----------------------

compo.imp.clr<-cenLR(compo.imp[,c(2:ncol(compo.imp))])
compo.imp.clr<-compo.imp.clr[[1]]
colnames(compo.imp.clr) <- paste(colnames(compo.imp.clr), "clr", sep = "_")
compo.imp.clr["Line"]<-compo.imp[,1]
compo.imp.clr <- compo.imp.clr %>%
  dplyr::select("Line", everything())

setwd("/Users/haimingliu/Documents/Post doc research/clr transformation/")

write.table(compo.imp.clr,file.name.compo.imp.clr.03,sep = ",",row.names = FALSE)

end.time<-Sys.time()
end.time-start.time
