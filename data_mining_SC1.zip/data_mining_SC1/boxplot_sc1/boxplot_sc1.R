library("ggplot2")

setwd("/Users/haimingliu/Documents/Post doc research/boxplot/")
#data format
data<-read.csv("02.data_sc1.csv",header = TRUE, 
                sep = ",", stringsAsFactors = FALSE)
data_active<- data[, 2:48]
stacked_df <- stack(data_active)
stacked_df

#box plot using ggplot
mytheme <- theme(
  plot.title= element_text(color = "#000000",size = 28, face = "bold"),
  plot.subtitle = element_text(color = "#000000", size = 20),
  axis.title.x = element_text(color = "#000000", size = 20, face = "bold"),
  axis.title.y = element_text(color= "#000000", size = 20, face = "bold"),
  axis.text.x = element_text(color = "#000000", size = 16),
  axis.text.y = element_text(color = "#000000", size = 16),
  axis.line = element_line(color = "black"),
  panel.border = element_rect(color = "black", fill =NA),
  plot.margin = unit(c(0.6, 0.5, 0.3, 0.6), "cm") #top, right, bottom, left
)
fancy_scientific <- function(l) {
  # turn in to character string in scientific notation
  l <- format(l, scientific = TRUE)
  # quote the part before the exponent to keep all the digits
  l <- gsub("^(.*)e", "'\\1'e", l)
  # remove + after exponent, if exists. E.g.: (3x10^+2 -> 3x10^2)
  l <- gsub("e\\+","e",l)
  # turn the 'e+' into plotmath format
  l <- gsub("e", "%*%10^", l)
  # convert 1x10^ or 1.000x10^ -> 10^
  l <- gsub("\\'1[\\.0]*\\'\\%\\*\\%", "", l)
  # return this as an expression
  parse(text=l)
}

b<-ggplot(stacked_df, aes(x=ind, y=values))+
  geom_boxplot(fill = "lightgray") +
  stat_summary(fun= mean, 
               geom = "point",
               shape = 16, 
               size = 2.5, 
               color = "#FC4E07")+
  scale_y_continuous(trans="log10",
                     labels = fancy_scientific)
print(b+mytheme+labs(
  title ="Boxplot of geochemical data",
  subtitle = "XXX mineral geochemical dataset",
  x = "Element",
  y = "Contents(ppm)"))
#output the plot
ggsave("boxplot_sc1.png")
