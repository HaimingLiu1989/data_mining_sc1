install.packages("dplyr")

library ("dplyr")

#read the data frame
start.time<-Sys.time()
setwd("/Users/haimingliu/Documents/Post doc research/Oxides tranformation/")
file.name.data.oxides.trans.03<-"03.data.oxides.trans_sc1.csv"
file.name.summary <-"summary_sc1.csv"
data<-read.csv("02.data_sc1.csv",header = TRUE,
                    sep = ",", stringsAsFactors = FALSE)
data
#transformed from oxides to element content then from wt% to ppm
data_trans <- data %>%
  select(MgO,Al2O3,SiO2,K2O,Y2O3,CaO,TiO2,V2O3,Cr2O3,Na2O,MnO,FeO,CoO,Yb2O3,P2O5,NiO) %>%
  mutate(Mg_ppm=10000*(MgO*24.31)/(24.31+16))%>%
  mutate(Al_ppm=10000*(Al2O3*2*26.98)/(26.98*2+16*3))%>%
  mutate(Si_ppm=10000*(SiO2*28.085)/(28.085+16*3))%>%
  mutate(K_ppm=10000*(K2O*2*39.1)/(39.1*2+16))%>%
  mutate(Y_ppm=10000*(Y2O3*2*88.906)/(88.906*2+15.999*3))%>%
  mutate(Ca_ppm=10000*(CaO*40.08)/(40.08+16))%>%
  mutate(Ti_ppm=10000*(TiO2*47.87)/(47.87+16*2))%>%
  mutate(V_ppm=10000*(V2O3*2*50.942)/(50.942*2+16*3))%>%
  mutate(Cr_ppm=10000*(Cr2O3*2*51.996)/(51.996*2+16*3))%>%
  mutate(Na_ppm=10000*(Na2O*2*22.99)/(22.99*2+16))%>%
  mutate(Mn_ppm=10000*(MnO*54.94)/(54.94+16))%>%
  mutate(Fe_ppm=10000*(FeO*55.85)/(55.85+16))%>%
  mutate(Co_ppm=10000*(CoO*58.933)/(58.933+16))%>%
  mutate(Yb_ppm=10000*(Yb2O3*2*173.05)/(173.05*2+16*3))%>%
  mutate(P_ppm=10000*(P2O5*2*30.974)/(30.974*2+16*5))%>%
  mutate(Ni_ppm=10000*(NiO*58.693)/(58.693+16))
data_trans

#screen data
data_trans[data_trans == 0] <- NA
summary <- summary (data_trans)
summary
#save the data
setwd("/Users/haimingliu/Documents/Post doc research/Oxides tranformation/")
write.table(data_trans,file.name.data.oxides.trans.03,sep = ",",row.names = FALSE)
write.table(summary, file.name.summary, sep=",",row.names = FALSE )
